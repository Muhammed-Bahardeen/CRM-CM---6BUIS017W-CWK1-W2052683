CWK1 - Market Analysis and Stock Segmentation Using RFM
========================================================

Study period: 2021-01-01 inclusive to 2025-01-01 exclusive
Benchmark: ^GSPC
Package created (UTC): 2026-11-24T12:30:54.755429+00:00

Folder guide
------------
data/
    S&P 500 constituent list and individual daily Yahoo Finance CSV snapshots.
outputs/
    Provenance, download failures, validation log, feature table, cluster assignments,
    clustering diagnostics, cluster profiles, cluster sizes, correlations, sensitivity
    results and sector composition tables.

Important
---------
The raw CSV files are preserved as downloaded/cached snapshots. The outputs are generated
by running the notebook from top to bottom. Include the notebook itself separately when
submitting the runnable code, and include your public GitHub repository address in the report.
